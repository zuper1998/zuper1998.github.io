/* needed header files*/
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>

/* TASK: include gn.h header file here */

// A BTP sender framework
int main(int argc, char* argv[]){

// Variables
	int err, i;
	int sd, ifindex;
	struct sockaddr_btp sbs;
	int len = sizeof(struct sockaddr_btp);
	unsigned char msg[2048] = {0};
	int index;
	int count;
	struct timeval current_time, base_time;
	int size, num;
	int shit = 0;
	int btp, pt, rep, scf, sec;
	unsigned char macAddr_c[6];
	unsigned int macAddr_i[6];

// The program should collect some data from arguments. At least 8 arguments are required
	if(argc != 9){
  //If args less then 8 print the usage:
		printf("btp_sender <btp_type> <pkt_type> <rep_interval> <pos_lat> <pos_long> <scf> <sec_profile> <peer_mac>\n");
		printf("-- Usage --\n");
		printf("<btp_type> BTP type 0:BTP_A/1:BTP_B\n");
		printf("<pkt_type> GeoNetworking packet type 0:GUC/1:SHB/2:TSB/3:GBC\n");
		printf("<rep_interval> Repat intervall:ms\n");
		printf("<pos_lat> GBC area center lat coordinate\n");
		printf("<pos_long> GBC area center long coordinate\n");
		printf("<scf> Store and forward 0:no/1:yes\n");
		printf("<sec_profile> packet secure: 0:None/1:CAM/2:DENM/3:Normal\n");
		printf("<peer_mac> In case of GUC the peers MAC address, format should be: XX:XX:XX:XX:XX:XX\n");
		printf("Example for usage: \n");
		printf("  btp_sender 0 1 1000 0 0 0 4 FF:FF:FF:FF:FF:FF\n");
		return 1;
	}

/* TASK: Use to atoi function to collect arguments. For example:	btp = atoi(argv[1]);*/
	/*
	  btp =          // BTP type
		pt =           // GeoNetworking packet type
		rep =          // rep_interval
		scf =          // Store and forward
		sec =          // Secure packets or not
	*/

/* TASK: I. Socket creation */
	/* sd =			// Socket	(return value should be greater then zero, if success. If return value is 0 or -1, then socket creation was unsuccesfull)

	//  Socket creation validation:
	if((sd <= 0){
				perror("ERROR in socket creation phase!");
			return 1;
		}
*/

	/* TASK: Fill the struct sbs */
	/*
	sbs.btp_family = PF_BTP;
	sbs.btp_type = 			// BTP type
	sbs.sport = 				// Source port in case of BTP-A
	sbs.dport = 				// Destination port BTP-A/BTP-B
	sbs.dport_info = 		// Destination port info BTP-B
	sbs.packet_type = 	// GeoNetworking packet type
	*/
	if(pt == 0){  /* GUC */
		/* process MAC address */
		if(sscanf(argv[7], "%2x:%2x:%2x:%2x:%2x:%2x\n", &macAddr_i[0], &macAddr_i[1], &macAddr_i[2], &macAddr_i[3], &macAddr_i[4], &macAddr_i[5]) != 6) {
			printf("Invalid MAC. Use the following format: XX:XX:XX:XX:XX:XX\n");
			return 0;
		}
		for(i = 0; i < 6; i++) {
			macAddr_c[i] = (unsigned char) macAddr_i[i];
		}
		memcpy(sbs.dest.addr.mid, macAddr_c, 6);	// MAC address to sbs with memcpy
	}
	else if(pt == 3){  /* GBC packet */

/* TASK: Struct sbs parameters in case of GBC */
	  /*sbs.dest.area.area_type = ;					// GeoNetworking area type. For example: circle, rectangle, ellipse. Allowed values: AT_CIRCLE, AT_RECT, AT_ELIP
		sbs.dest.area.pos_latitude = ;				// WGS-84 latitude for the center position of the geometric shape.
		sbs.dest.area.pos_longitude = ;				// WGS-84 longitude for the center position of the geometric shape.
		sbs.dest.area.distance_a = ;					// Distance a of the geometric shape in meters.
		sbs.dest.area.distance_b = ;					// Distance b of the geometric shape in meters.
		sbs.dest.area.angle = 0;							// Angle of the geometric shape in degrees form North.
		*/

	}
	//Other parameters of the struct sbs
	sbs.packet_lifetime.multiplier = 12; 		// Packet lifetime multiplier
	sbs.packet_lifetime.base = 1;  					// Packet lifetime base	/* 12 * 1s = 12s */
	sbs.max_repeat_time = 10 * 1000;  			// Max repetation time			/* 10s */
	sbs.repeat_interval = rep;							// Repeat_interval from argument
	sbs.hop_limit = 10;											// Hop limit
	sbs.comm_profile = CP_G5A;							// Communication profile (ITS-G5A)
	sbs.sec_profile = 0;										// Security profile (we don't use it - 0)
	sbs.tc.tc_scf = scf;
	sbs.tc.tc_id= 0;
	sbs.tc.tc_co= 0;

/* TASK: II. Bind to socket*/
/*	err = 	// Bind to sd socket. If success err=0, otherwise -1.
		if(	err != 0){
			perror("Error in binding!\n");
			close(sd);	//close socket
			return -1;  // return -1
		}
*/

/* TASK: III. Send package */
	// Create a demo message for payload
	/*msg = "";		//The message that should be send. For example: msg = "Demo message";
		err =	//Call sendto function
		if(err < 0){
				perror("Error during the sending phase!\n");
				return -1;	// return with -1
		}
*/

/* TASK: IV. Socket closing */
	/* close(socket id); */
	return 0; 	// return value
} //main() end
